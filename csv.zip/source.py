# -*- coding: utf-8 -*-
"""
Created on Mon Aug 23 17:29:33 2021

@author: farnaz
"""
import csv
from statistics import mean 
import operator




#code behine for getting the average for students
#code behine for getting the average for students
def calculate_averages(input_file_name, output_file_name):
 with open(input_file_name, 'r') as csvfile:
    reader = csv.reader(csvfile)
    with open(output_file_name, 'w', newline='') as outfile:
        writer = csv.writer(outfile)

        for row in reader:
            grade_mean = (float(grade) for grade in row[1:])
            writer.writerow([row[0], mean(grade_mean)])


def calculate_sorted_averages(input_file_name, output_file_name):

 with open(input_file_name, newline='') as csvfile:
    separators = csv.reader(csvfile)
    result = {}
    for line in separators:
        name = line[0]
        gpa = mean([float(item) for item in line[1:]])
        result[name] = gpa
    sorted_results = dict( sorted(result.items(), key=operator.itemgetter(1)))
    y = sorted([(key, value)  for key, value in sorted_results.items()],  key=lambda t: (t[0],t[1]), reverse=True)
    with open(output_file_name, 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        for item in y:
            writer.writerow(item) 
            
            
def calculate_three_best(input_file_name, output_file_name):           
            
 with open(input_file_name, newline='') as csvfile:
    separators = csv.reader(csvfile)
    result = {}
    for line in separators:
        name = line[0]
        gpa = mean([float(item) for item in line[1:]])
        result[name] = gpa
    sorted_results = dict(sorted(result.items(), key=operator.itemgetter(1))) 
    y = sorted([(key, value)  for key, value in sorted_results.items()],  key=lambda t: (t[1],t[0]), reverse=True)[:3]
    with open(output_file_name, 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        for item in y:
            writer.writerow(item) 
            
            
def calculate_three_worst(input_file_name, output_file_name):
 
 with open(input_file_name , newline='') as csvfile:
    separators = csv.reader(csvfile)
    result = {}
    for line in separators:
        name = line[0]
        gpa = mean([float(item) for item in line[1:]])
        result[name] = gpa
    sorted_results = dict(sorted(result.items(), key=operator.itemgetter(1))) 
    y = sorted([(key, value)  for key, value in sorted_results.items()],  key=lambda t: (t[1],t[0]), reverse=False)[:3]
    with open(output_file_name, 'w', newline='') as outfile:
        writer = csv.writer(outfile)
        for item in y:
            # yy =list(item)[1]
            writer.writerow(item[1:]) 
            
def calculate_average_of_averages(input_file_name, output_file_name):

 with open(input_file_name , newline='') as csvfile:
    separators = csv.reader(csvfile)
    result = {}
    for line in separators:
        name = line[0]
        gpa = mean([float(item) for item in line[1:]])
        result[name] = gpa
    sorted_results = dict(sorted(result.items(), key=operator.itemgetter(1))) 
    res = 0
    for val in sorted_results.values():
     res += val
    res = res / len(sorted_results)
# print("The computed mean : " + str(res)) 
    float_list = [res]
    
    with open(output_file_name, "w",newline='') as file:
      writer = csv.writer(file, delimiter='\n')
      for num in float_list:
        writer.writerow(float_list)

            

